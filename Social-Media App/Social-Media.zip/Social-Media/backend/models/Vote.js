// models/Vote.js
import mongoose from "mongoose";

const voteSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  post: { type: mongoose.Schema.Types.ObjectId, ref: "Post" },
  tag: String,
  createdAt: { type: Date, default: Date.now },
});

export default mongoose.model("Vote", voteSchema);
