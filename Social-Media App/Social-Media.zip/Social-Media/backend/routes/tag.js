// routes/tag.js
import express from "express";
import { getTrendingTags } from "../controllers/tagController.js";

const router = express.Router();

router.get("/trending", getTrendingTags);

export default router;
