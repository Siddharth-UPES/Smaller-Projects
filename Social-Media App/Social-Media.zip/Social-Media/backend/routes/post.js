// routes/post.js
import express from "express";
import { uploadPost, getFeedPosts, getPostsByTag, likePost, unlikePost, deletePost } from "../controllers/postController.js";
import { protect } from "../middleware/authMiddleware.js";
import { upload } from "../middleware/uploadMiddleware.js";

const router = express.Router();

router.post("/upload", protect, upload.single("image"), uploadPost);
router.get("/feed", protect, getFeedPosts);
router.get("/tag/:tagName", protect, getPostsByTag);
router.post("/like/:postId", protect, likePost);
router.delete("/unlike/:postId", protect, unlikePost);
router.delete("/delete/:postId", protect, deletePost);

export default router;
