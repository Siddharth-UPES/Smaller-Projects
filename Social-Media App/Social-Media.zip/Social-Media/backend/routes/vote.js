// routes/vote.js
import express from "express";
import { voteOnPost, getVotingPosts } from "../controllers/voteController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.post("/", protect, voteOnPost);
router.get("/:tagName", protect, getVotingPosts);

export default router;
