// src/pages/Explore.js
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "../api/axios";
import PostCard from "../components/PostCard";
import "../styles/Global.css";

function Explore() {
  const { tag } = useParams();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const currentUserId = localStorage.getItem("userId");

  useEffect(() => {
    const fetchByTag = async () => {
      try {
        const res = await axios.get(`/posts/tag/${tag}`, {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });
        setPosts(res.data);
      } catch (err) {
        console.error("Failed to fetch posts for the tag", err);
      } finally {
        setLoading(false);
      }
    };
    fetchByTag();
  }, [tag]);

  if (loading) {
    return (
      <div className="container mt-4">
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <h3 className="mb-3">Posts with tag: #{tag}</h3>
      {posts.length > 0 ? (
        <div className="row">
          {posts.map((post) => (
            <div className="col-md-4 mb-3" key={post._id}>
              <PostCard post={post} currentUserId={currentUserId} />
            </div>
          ))}
        </div>
      ) : (
        // Optionally, show nothing or a friendly message
        <p className="text-muted">No posts available for this tag.</p>
      )}
    </div>
  );
}

export default Explore;
