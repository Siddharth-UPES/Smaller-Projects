
// src/pages/Vote.js
import React, { useState, useEffect } from "react";
import axios from "../api/axios";
import PostCard from "../components/PostCard";
import TrendingTags from "../components/TrendingTags";
import "../styles/Global.css";
import { useNavigate, useParams } from "react-router-dom";

function Vote() {
  const { tag: urlTag } = useParams();
  const [tag, setTag] = useState(urlTag || "");
  const [inputTag, setInputTag] = useState("");
  const [posts, setPosts] = useState([]);
  const [message, setMessage] = useState("");
  const currentUserId = localStorage.getItem("userId");

  const fetchVotingPosts = async (selectedTag) => {
    try {
      // Assuming the vote endpoint returns posts for a given tag
      const res = await axios.get(`/votes/${selectedTag}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      setPosts(res.data);
    } catch (error) {
      setMessage(error.response?.data?.message || "Failed to fetch voting posts");
    }
  };

  useEffect(() => {
    if (tag) {
      fetchVotingPosts(tag);
    }
  }, [tag]);

  const handleTagSubmit = (e) => {
    e.preventDefault();
    if (inputTag.trim() !== "") {
      setTag(inputTag.trim());
      setMessage("");
    }
  };

  return (
    <div className="container mt-4">
      <h3 className="mb-3">Vote by Tag</h3>
      <form onSubmit={handleTagSubmit} className="mb-3">
        <input
          type="text"
          className="input-box"
          placeholder="Enter tag to filter images"
          value={inputTag}
          onChange={(e) => setInputTag(e.target.value)}
        />
        <button className="submit-btn" type="submit">
          Show Posts
        </button>
      </form>
      {message && <div className="alert alert-info">{message}</div>}
      {tag === "" ? (
        <p className="text-muted">Please enter a tag to vote on images.</p>
      ) : posts.length > 0 ? (
        <div className="row">
          {posts.map((post) => (
            <div className="col-md-4 mb-3" key={post._id}>
              <PostCard
                post={post}
                currentUserId={currentUserId}
                showVoteButton={true}
                voteTag={tag}
              />
            </div>
          ))}
        </div>
      ) : (
        <p className="text-muted">No posts available for this tag.</p>
      )}
      <TrendingTags />
    </div>
  );
}

export default Vote;
