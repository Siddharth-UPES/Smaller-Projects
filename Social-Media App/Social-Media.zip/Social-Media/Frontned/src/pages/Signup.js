
// src/pages/Signup.js
import React, { useState } from "react";
import { signup } from "../api/auth";
import { useNavigate } from "react-router-dom";
import "../styles/Global.css";

export default function Signup() {
  const [form, setForm] = useState({
    username: "",
    email: "",
    password: "",
    bio: "",
  });
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSignup = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const res = await signup(form);
      // Expecting a message from the backend upon successful signup
      if (res && res.message === "User created successfully") {
        navigate("/login");
      } else {
        throw new Error("Signup failed: Something went wrong");
      }
    } catch (err) {
      console.error("Signup error:", err);
      const errorMsg =
        (err.response && err.response.data && err.response.data.message) ||
        err.message ||
        "Signup failed";
      setError(errorMsg);
    }
  };

  return (
    <div className="container">
      <h1>Social-Media</h1>
      <h2>Create Your Account</h2>
      {error && <div className="alert alert-danger">{error}</div>}
      <form onSubmit={handleSignup}>
        <input
          className="input-box"
          type="text"
          name="username"
          placeholder="Enter Username"
          onChange={handleChange}
          required
        />
        <input
          className="input-box"
          type="email"
          name="email"
          placeholder="Enter Email"
          onChange={handleChange}
          required
        />
        <input
          className="input-box"
          type="password"
          name="password"
          placeholder="Enter Password"
          onChange={handleChange}
          required
        />
        <textarea
          className="input-box"
          name="bio"
          placeholder="Enter Bio (optional)"
          rows="2"
          onChange={handleChange}
        />
        <button className="submit-btn" type="submit">
          Signup
        </button>
      </form>
    </div>
  );
}
