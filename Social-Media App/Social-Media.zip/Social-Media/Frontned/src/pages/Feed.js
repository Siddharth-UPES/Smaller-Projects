
// src/pages/Feed.js
import React, { useState, useEffect } from "react";
import axios from "../api/axios";
import PostCard from "../components/PostCard";
import TrendingTags from "../components/TrendingTags";
import "../styles/Global.css";

function Feed() {
  const [posts, setPosts] = useState([]);
  const currentUserId = localStorage.getItem("userId");

  useEffect(() => {
    const fetchFeed = async () => {
      try {
        const res = await axios.get("/posts/feed", {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });
        setPosts(res.data);
      } catch (error) {
        console.error(error.response?.data?.message || "Failed to fetch feed");
      }
    };
    fetchFeed();
  }, []);

  const removePostFromState = (postId) => {
    setPosts((prevPosts) => prevPosts.filter((post) => post._id !== postId));
  };

  return (
    <div className="container mt-4 feed-container">
      <div className="row">
        <div className="col-md-8">
          <h2 className="mb-4">Feed</h2>
          {posts.length === 0 ? (
            <div className="alert alert-warning">No posts yet.</div>
          ) : (
            posts.map((post) => (
              <PostCard
                key={post._id}
                post={post}
                currentUserId={currentUserId}
                onPostDelete={removePostFromState}
              />
            ))
          )}
        </div>
        <div className="col-md-4">
          <TrendingTags />
        </div>
      </div>
    </div>
  );
}

export default Feed;
