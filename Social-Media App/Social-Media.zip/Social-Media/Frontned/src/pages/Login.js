
// src/pages/Login.js
import React, { useState } from "react";
import { login } from "../api/auth";
import { useNavigate } from "react-router-dom";
import "../styles/Global.css";

export default function Login() {
  const [form, setForm] = useState({ identifier: "", password: "" });
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const res = await login(form);
      // Check whether token exists in response
      if (res && res.token) {
        localStorage.setItem("token", res.token);
        localStorage.setItem("userId", res.user?.id || "");
        navigate("/");
      } else {
        throw new Error("Login failed: no token received");
      }
    } catch (err) {
      console.error("Login error:", err);
      // Check if err.response.data.message is defined; if not, use err.message or fallback message.
      const errorMsg =
        (err.response && err.response.data && err.response.data.message) ||
        err.message ||
        "Login failed";
      setError(errorMsg);
    }
  };

  return (
    <div className="container">
      <h1>Social-Media</h1>
      <h2>Welcome Back</h2>
      {error && <div className="alert alert-danger">{error}</div>}
      <form onSubmit={handleLogin}>
        <input
          className="input-box"
          type="text"
          name="identifier"
          placeholder="Username or Email"
          onChange={handleChange}
          required
        />
        <input
          className="input-box"
          type="password"
          name="password"
          placeholder="Enter Password"
          onChange={handleChange}
          required
        />
        <button className="submit-btn" type="submit">
          Login
        </button>
      </form>
    </div>
  );
}
