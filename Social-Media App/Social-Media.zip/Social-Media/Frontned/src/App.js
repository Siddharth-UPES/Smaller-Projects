
// src/App.js
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Feed from "./pages/Feed";
import Upload from "./pages/Upload";
import Vote from "./pages/Vote";
import Explore from "./pages/Explore";
import Navbar from "./components/Navbar";
import 'bootstrap/dist/css/bootstrap.min.css';
import "./styles/Global.css"; // make sure this is imported

function App() {
  return (
    <Router>
      <Navbar />
      {/* Bubble container inserted at the top level */}
      <div className="bubbles">
        <div className="bubble"></div>
        <div className="bubble"></div>
        <div className="bubble"></div>
        <div className="bubble"></div>
        <div className="bubble"></div>
      </div>
      <Routes>
        <Route path="/" element={<Feed />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/upload" element={<Upload />} />
        <Route path="/vote/:tag" element={<Vote />} />
        <Route path="/explore/:tag" element={<Explore />} />
      </Routes>
    </Router>
  );
}

export default App;
