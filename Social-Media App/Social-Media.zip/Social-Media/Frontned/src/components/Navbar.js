
// src/components/Navbar.js
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import "../styles/Global.css";

function Navbar() {
  const navigate = useNavigate();
  const location = useLocation();
  const token = localStorage.getItem("token");
  const [isAuthenticated, setIsAuthenticated] = useState(!!token);

  useEffect(() => {
    setIsAuthenticated(!!localStorage.getItem("token"));
  }, [location]);

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userId");
    navigate("/login");
  };

  const navLinkClass = (path) =>
    `nav-link ${location.pathname === path ? "active text-warning" : "text-dark"}`;

  return (
    <nav className="navbar navbar-expand-lg bg-light shadow-sm">
      <div className="container">
        <Link className="navbar-brand fw-bold fs-4" to="/">
          Social-Media
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarContent"
        >
          <span className="navbar-toggler-icon" />
        </button>
        <div className="collapse navbar-collapse" id="navbarContent">
          <ul className="navbar-nav ms-auto mb-2 mb-lg-0 gap-2">
            <li className="nav-item">
              <Link className={navLinkClass("/")} to="/">
                Feed
              </Link>
            </li>
            <li className="nav-item">
              <Link className={navLinkClass("/upload")} to="/upload">
                Upload
              </Link>
            </li>
            <li className="nav-item">
              <Link className={navLinkClass("/vote/sunset")} to="/vote/sunset">
                Vote
              </Link>
            </li>
            {isAuthenticated ? (
              <li className="nav-item">
                <button
                  onClick={logout}
                  className="btn btn-sm btn-outline-warning ms-2"
                >
                  Logout
                </button>
              </li>
            ) : (
              <>
                <li className="nav-item">
                  <Link className={navLinkClass("/login")} to="/login">
                    Login
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className={navLinkClass("/signup")} to="/signup">
                    Signup
                  </Link>
                </li>
              </>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
