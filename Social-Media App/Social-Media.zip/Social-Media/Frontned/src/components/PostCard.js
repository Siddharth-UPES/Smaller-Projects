
// src/components/PostCard.js
import React, { useState, useEffect } from "react";
import axios from "../api/axios";

function PostCard({ post, currentUserId, onPostDelete, showVoteButton = false, voteTag = "" }) {
  const [likes, setLikes] = useState(post.likes || 0);
  const [liked, setLiked] = useState(false);
  const [voteCount, setVoteCount] = useState(post.votes || 0);

  // Set initial liked state based on whether the current user id is in the likedBy array
  useEffect(() => {
    if (post.likedBy && currentUserId) {
      setLiked(post.likedBy.includes(currentUserId));
    }
  }, [post.likedBy, currentUserId]);

  const handleLikeToggle = async () => {
    try {
      if (liked) {
        // Unlike the post
        await axios.delete(`/posts/unlike/${post._id}`, {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });
        setLikes((prev) => prev - 1);
        setLiked(false);
      } else {
        // Like the post
        await axios.post(`/posts/like/${post._id}`, {}, {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });
        setLikes((prev) => prev + 1);
        setLiked(true);
      }
    } catch (err) {
      alert(err.response?.data?.message || "Action failed");
    }
  };

  const handleDelete = async () => {
    if (window.confirm("Are you sure you want to delete this post?")) {
      try {
        await axios.delete(`/posts/delete/${post._id}`, {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });
        if (onPostDelete) onPostDelete(post._id);
      } catch (err) {
        alert(err.response?.data?.message || "Delete failed");
      }
    }
  };

  const handleVote = async () => {
    try {
      if (!voteTag) {
        alert("No vote tag provided");
        return;
      }
      await axios.post("/votes", { postId: post._id, tag: voteTag }, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      setVoteCount((prev) => prev + 1);
    } catch (err) {
      alert(err.response?.data?.message || "Vote failed");
    }
  };

  return (
    <div className="card mb-4 shadow-sm">
      <img
        src={`http://localhost:5000${post.imageUrl}`}
        alt="Post"
        style={{
          width: "100%",
          height: "300px",       // Fixed height for an Instagram-like thumbnail
          objectFit: "cover",
          borderTopLeftRadius: "inherit",
          borderTopRightRadius: "inherit",
        }}
      />
      <div className="card-body">
        <h5 className="card-title">{post.caption}</h5>
        <p className="card-text text-muted">Tags: {post.tags.join(", ")}</p>
        {/* Display like and vote counts */}
        <div className="d-flex justify-content-between align-items-center mb-2">
          <span>👍 {likes}</span>
          <span>🗳 {voteCount}</span>
        </div>
        <div className="d-flex justify-content-end align-items-center">
          <button
            className="btn btn-outline-primary btn-sm me-2"
            onClick={handleLikeToggle}
          >
            {liked ? "Unlike" : "Like"}
          </button>
          {post.uploader.toString() === currentUserId && (
            <button className="btn btn-danger btn-sm me-2" onClick={handleDelete}>
              Delete
            </button>
          )}
          {showVoteButton && voteTag && (
            <button
              className="btn btn-success btn-sm"
              onClick={handleVote}
            >
              Vote for this
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default PostCard;
