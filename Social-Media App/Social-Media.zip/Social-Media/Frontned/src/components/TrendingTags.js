
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "../api/axios";

function TrendingTags() {
  const [tags, setTags] = useState([]);
  const [loading, setLoading] = useState(true);

  // Read token unconditionally.
  const token = localStorage.getItem("token");

  useEffect(() => {
    if (!token) {
      // If no token, we set loading to false and skip fetching.
      setLoading(false);
      return;
    }
    const fetchTrending = async () => {
      try {
        const res = await axios.get("/tags/trending");
        setTags(res.data);
      } catch (err) {
        console.error("Error fetching tags", err);
      } finally {
        setLoading(false);
      }
    };
    fetchTrending();
  }, [token]);

  // Conditionally render nothing if no token.
  if (!token) return null;

  return (
    <div className="card p-3 shadow-sm sticky-top" style={{ top: "100px" }}>
      <h5 className="mb-3 text-primary">🔥 Trending Tags</h5>
      {loading ? (
        <div className="text-muted">Loading...</div>
      ) : tags.length === 0 ? (
        <p className="text-muted">No trending tags yet.</p>
      ) : (
        <div className="d-flex flex-wrap gap-2">
          {tags.map((tag) => (
            <Link
              key={tag._id}
              to={`/explore/${tag._id}`}
              className="btn btn-sm btn-outline-secondary rounded-pill d-flex align-items-center"
              style={{ textDecoration: "none" }}
            >
              #{tag._id}
              <span className="badge bg-primary ms-2">{tag.count}</span>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

export default TrendingTags;
