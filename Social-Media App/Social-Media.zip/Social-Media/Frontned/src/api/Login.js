// frontend/src/api/Login.js
import React, { useState } from "react";
import { login } from "../api/auth";
import "../styles/Auth.css";

export default function Login() {
  const [form, setForm] = useState({ username: "", password: "" });
  const [error, setError] = useState("");

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleLogin = async () => {
    setError("");
    try {
      const res = await login(form);
      localStorage.setItem("token", res.token);
      alert("Login successful!");
    } catch (err) {
      setError(err.response.data.message);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-card" style={{ maxWidth: "400px" }}>
        <h2 className="auth-title">🔐 Login</h2>
        {error && <div className="alert alert-danger">{error}</div>}
        <div className="mb-3">
          <input
            className="form-control auth-input"
            name="username"
            onChange={handleChange}
            placeholder="Username"
          />
        </div>
        <div className="mb-3">
          <input
            type="password"
            className="form-control auth-input"
            name="password"
            onChange={handleChange}
            placeholder="Password"
          />
        </div>
        <button className="btn btn-primary auth-button w-100" onClick={handleLogin}>
          Login
        </button>
      </div>
    </div>
  );
}
