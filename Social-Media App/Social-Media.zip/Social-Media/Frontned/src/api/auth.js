import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:5000/api/auth",
});

// Signup
export const signup = async (userData) => {
  const res = await API.post("/signup", userData);
  return res.data;
};

// Login
export const login = async (credentials) => {
  const res = await API.post("/login", credentials);
  return res.data;
};
